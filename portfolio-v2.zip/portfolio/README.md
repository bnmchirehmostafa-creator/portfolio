# Nour Elislam Rebahi – Portfolio

Site personnel professionnel d'**Ingénieur en Génie Civil**.

## 🔗 Lien du site

Après activation de GitHub Pages, le site sera disponible sur :

```
https://VOTRE-USERNAME.github.io/VOTRE-REPO/
```

## ✏️ Mode édition

1. Cliquez sur le bouton **Modifier** en haut à droite
2. Modifiez n'importe quel texte
3. Cliquez sur **Sauvegarder**

Les modifications sont enregistrées localement dans le navigateur.

## 🚀 Comment publier sur GitHub Pages

1. Créez un nouveau dépôt (repository) sur GitHub
2. Uploadez tous les fichiers de ce dossier
3. Allez dans **Settings → Pages**
4. Sous **Source**, choisissez `Deploy from a branch`
5. Sélectionnez la branche `main` et le dossier `/ (root)`
6. Cliquez sur **Save**

Le site sera en ligne après 1–2 minutes.

## 📁 Structure

```
├── index.html      # Page principale du site
└── README.md       # Ce fichier
```

## 🛠️ Technologies

- HTML5 / CSS3 / JavaScript (vanilla)
- Design responsive
- Mode édition avec localStorage

---

© 2026 Nour Elislam Rebahi
